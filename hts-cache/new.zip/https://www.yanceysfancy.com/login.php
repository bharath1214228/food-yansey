<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
<meta http-equiv='X-UA-Compatible' content='IE=edge' />
        <title> Login Required </title>
        <meta http-equiv='Content-Type' content='text/html; charset=UTF-8' />
        <meta http-equiv="Cache-Control" content="no-cache" />
        <meta http-equiv="Pragma" content="no-cache" />
        <meta name="Keywords" content="" />
        <meta name="Description" content="" />
        <link rel="shortcut icon" href="/templates/favicon.ico" />
        
        <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script><script type="text/javascript">$.noConflict();</script>

<script type='text/javascript'>
var isLinuxServer = true; var isWindowsServer = false; var PF_QUICK_INFO_BLOCK_WIDTH = 200; var PF_QUICK_LAUNCH_BLOCK_HEIGHT = 100; var PF_QUICK_INFO_START = false; var PF_QUICK_LAUNCH_START = false; var TINYMCE_IMAGE_MANAGER_COMPONENT = 'imagemanager';  var TINYMCE_FILE_MANAGER_COMPONENT = 'filemanager'; var PF_WYSIWYG_ENGINE = 'CKEDITOR'; var PF_IS_CKEDITOR = 1; var CKEDITOR_BASEPATH = '/cmscore/ckeditor/4.5.7/'; var PF_IS_WYSIWYG_PRO = 0; var PF_IS_TINYMCE = 0;
</script>

<script type="text/javascript">var djConfig = {"baseUrl":"\/fission\/js\/dojo\/dojo\/","parseOnLoad":true,"modulePaths":{"pf":"\/fission\/js\/pf","cms":"\/js\/cms","cmsx":"\/app\/js\/cmsx"},"isDebug":false};</script>

<script src='/cmscore/css-js/bcbbb91b2c06df9f7b91636fbc01de50.js?v=1.25.11.f393ab32' type='text/javascript'></script>

        
<link href='/templates/back/css/page.css?v=1.25.11.f393ab32' rel='stylesheet' type='text/css'  />
<link href='/templates/back/css/form.css?v=1.25.11.f393ab32' rel='stylesheet' type='text/css'  />
<link href='/templates/front/css/form-imagedrop.css?v=1.25.11.f393ab32' rel='stylesheet' type='text/css'  />
<link href='/templates/front/css/form-radio-checks.css?v=1.25.11.f393ab32' rel='stylesheet' type='text/css'  />
<link href='/templates/front/css/modules/rss-feed.css?v=1.25.11.f393ab32' rel='stylesheet' type='text/css'  />
<link href='/templates/front/css/modules/catalog-categories.css?v=1.25.11.f393ab32' rel='stylesheet' type='text/css'  />
<link href='/templates/front/css/modules/modules.css?v=1.25.11.f393ab32' rel='stylesheet' type='text/css'  />
<link href='/templates/back/css/popup-shadows.css?v=1.25.11.f393ab32' rel='stylesheet' type='text/css'  />
<link href='/templates/back/css/popup-windows.css?v=1.25.11.f393ab32' rel='stylesheet' type='text/css'  />
<link href='/templates/back/css/overlib.css?v=1.25.11.f393ab32' rel='stylesheet' type='text/css'  />
<link href='/templates/back/css/login-form.css?v=1.25.11.f393ab32' rel='stylesheet' type='text/css'  />
<link href='/templates/back/css/list.css?v=1.25.11.f393ab32' rel='stylesheet' type='text/css'  />
<link href='/templates/back/css/tree.css?v=1.25.11.f393ab32' rel='stylesheet' type='text/css'  />
<link href='/cmscore/css/growler.css?v=1.25.11.f393ab32' rel='stylesheet' type='text/css'  />
<link href='/cmscore/css/font-awesome.css?v=1.25.11.f393ab32' rel='stylesheet' type='text/css'  />
<link href='/cmscore/css/form-website-field.css?v=1.25.11.f393ab32' rel='stylesheet' type='text/css'  />
<!--[if lte IE 7]>
<link href='/templates/back/css/popup-windows.ie7.css?v=1.25.11.f393ab32' rel='stylesheet' type='text/css'  />
<![endif]-->
<link href='/cmscore/js/dojo/dijit/themes/dijit.css?v=1.25.11.f393ab32' rel='stylesheet' type='text/css'/>
<link href='/cmscore/js/dojo/dijit/themes/claro/claro.css?v=1.25.11.f393ab32' rel='stylesheet' type='text/css'/>

        
    </head>
    <body class='login-body' onload="if(e=document.getElementById('username')){e.focus();}">
        <div style='text-align:center; width:100%; padding-top:60px;'>
            <div id='login_box' style='background-image:url(/app/templates/back/images/login-box-backer.png);'>
                <div id='login_box_elements'>
                <form id='login_form' name='login_form' action="/login.php" method='post'  data-pf-form="true" style='margin:0px;'>
<input name='form_name' id='login_form_form_name' type='hidden' value='login_form' />
<input name='form_event' id='login_form_form_event' type='hidden' value='submit' />
<input type='hidden' name='task' id='task' value="process-login" />

<table border='0' cellpadding='0' cellspacing='0' align='center' >
    <tr>
        <td class='form-caption-login' nowrap='nowrap'>Username :</td>
        <td class='form-element-login'><input type='text' name='username' id='username' value="" tabindex="1" class="login-text-off" onfocus=" this.className='login-text-on';" onblur=" this.className='login-text-off';" /></td>
        <td rowspan='2' style='padding-top:3px; padding-left:8px;' align='left'>
            <div><input type='submit' name='login' id='login' value="Login" tabindex="3" class="login-submit-off" onmouseover=" this.className='login-submit-over';" onmouseout=" this.className='login-submit-off';" onfocus=" this.className='login-submit-on';" onblur=" this.className='login-submit-off';" /></div><div style='padding-top:3px; padding-left:2px;'><a href='/forgot-password.php' class='login-box'>Forgot Password?</a><br /><a href='/' class='login-box'>Go To Homepage</a></div>            
        </td>
    </tr>
    <tr>
        <td class='form-caption-login' nowrap='nowrap'>Password :</td>
        <td class='form-element-login'><input type='password' name='password' id='password' value="" autocomplete="off" tabindex="2" class="login-password-off" onfocus=" this.className='login-password-on';" onblur=" this.className='login-password-off';" /></td>
    </tr>    
</table>
</form>
                </div>
            </div>
        </div>
        
    </body>
</html>